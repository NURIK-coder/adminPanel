import { Routes, Route, BrowserRouter } from "react-router-dom"
import Error from "../pages/Eror";
import TestPage from "../pages/Test";
import TestDetail from "../pages/TestDetail";
import Login from "../pages/Login";
import Applications from "../pages/admin/Applicarions";
import Dashboard from "../pages/admin/Dashboard";
import Profile from "../pages/admin/Profile";




function Layout(){
    return(
        <>
        <BrowserRouter>
        <Routes>
            <Route path="/" element={<Login />} />
            <Route
            path={'/testsList/'}
            element={<TestPage/>}
            />
            <Route
            path={'/test/:id'}
            element={<TestDetail/>}
            />
            <Route
            path="/admin/login"
            element={<Login/>}
            />
            <Route
            path="/admin/applications"
            element={<Applications/>}/>
            <Route
            path="/admin/dashboard"
            element={<Dashboard/>}/>
            <Route
            path="/admin/profile"
            element={<Profile/>}/>
            <Route
            path='*'
            element={<Error/>}
            />
    
        </Routes>
    </BrowserRouter>
        </>
    
    )
}

export default Layout;