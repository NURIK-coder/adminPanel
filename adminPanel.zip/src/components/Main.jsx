import Layout from "./Layout";

function Main(){
    return(
        <Layout/>
    )
}

export default Main;