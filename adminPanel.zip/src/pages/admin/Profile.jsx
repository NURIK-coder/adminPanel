import React, { useEffect } from "react"
import { useSelector } from "react-redux"
import { store } from "../../store/store"
import { CurrentUser } from "../../store/user/userActions"
import AdminSidebar from "./AdminSideBar"

export default function ProfilePage() {
  const user = useSelector(u => u.userInfo.user)
  
  useEffect(() => {
    store.dispatch(CurrentUser())
  }, [])

  // Защита: если данные ещё не загружены
  if (!user || user == null) {
    return <p className="text-center mt-10 text-gray-600">Yuklanmoqda...</p>
  }

  return (
    
    <div className="max-w-6xl mx-auto p-6 bg-[#f5f8fa] space-y-6">
      {/* Header */}
      <AdminSidebar />
      <div className="bg-white p-6 rounded-lg shadow flex items-center gap-6">
        <img
          src='https://sbcf.fr/wp-content/uploads/2018/03/sbcf-default-avatar.png'
          alt="avatar"
          className="w-20 h-20 rounded-full border-2 border-green-500"
        />
        <div>
          <h2 className="text-xl font-semibold">{user.first_name} {user.last_name}</h2>
          <p className="text-gray-500 capitalize">{user.role}</p>
          <p className="text-gray-400 text-sm">{user.university1}</p>
        </div>
      </div>

      {/* Shaxsiy ma'lumotlar */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-800">Shaxsiy ma'lumotlar</h3>
          <button className="bg-blue-500 text-white px-4 py-1 rounded hover:bg-blue-600">
            Tahrirlash
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-gray-700">
          <div>
            <p className="text-sm text-gray-500">Foydalanuvchi nomi</p>
            <p className="font-medium">@{user.username}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Email</p>
            <p className="font-medium">{user.email || "—"}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Faollik</p>
            <p className="font-medium">{user.is_active ? "Faol" : "Faol emas"}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Ball qo'yishi mumkinmi</p>
            <p className="font-medium">{user.can_score ? "Ha" : "Yo'q"}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Barcha talabalar ruxsat etilganmi?</p>
            <p className="font-medium">{user.allow_all_students ? "Ha" : "Yo'q"}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Kurs bo‘yicha cheklov</p>
            <p className="font-medium">{user.limit_by_course ? "Ha" : "Yo'q"}</p>
          </div>
        </div>
      </div>
      <div className="flex gap-4 justify-center flex-wrap">
        {/* Fakultetlar */}
        <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">🎓 Fakultetlar</h3>
            {user.faculties?.length > 0 ? (
            <ul className="list-disc list-inside text-gray-700">
                {user.faculties.map((f, i) => (
                <li key={i}>{f}</li>
                ))}
            </ul>
            ) : (
            <p className="text-gray-500">Fakultet biriktirilmagan</p>
            )}
        </div>

        {/* Yo‘nalishlar */}
        <div className="bg-white p-6 rounded-lg shadow ">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">📚 Yo‘nalishlar</h3>
            {user.directions?.length > 0 ? (
            <ul className="list-disc list-inside text-gray-700 text-left">
                {user.directions.map((d, i) => (
                <li key={i}>{d}</li>
                ))}
            </ul>
            ) : (
            <p className="text-gray-500">Yo‘nalishlar mavjud emas</p>
            )}
        </div>

        {/* Bosqichlar */}
        <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">📌 Bosqichlar</h3>
            {user.levels?.length > 0 ? (
            <ul className="list-disc list-inside text-gray-700">
                {user.levels.map((l, i) => (
                <li key={i}>{l}</li>
                ))}
            </ul>
            ) : (
            <p className="text-gray-500">Bosqichlar biriktirilmagan</p>
            )}
        </div>

        {/* Bo‘limlar */}
        <div className="bg-white p-6 rounded-lg shadow ">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">📖 Bo‘limlar</h3>
            {user.sections?.length > 0 ? (
            <ul className="list-disc list-inside text-gray-700">
                {user.sections.map((s, i) => (
                <li key={i}>{s}</li>
                ))}
            </ul>
            ) : (
            <p className="text-gray-500">Bo‘limlar mavjud emas</p>
            )}
        </div>
      </div>
      
    </div>
  )
}
