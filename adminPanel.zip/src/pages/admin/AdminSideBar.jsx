import { useEffect, useRef, useState } from "react"
import { Link } from "react-router-dom"
import { motion, AnimatePresence } from "framer-motion"

export default function AdminSidebar() {
    const [isOpen, setIsOpen] = useState(false)
    const sidebarRef = useRef()
    const buttonRef = useRef()
    

    useEffect(() => {
        const handleClickOutside = (event) => {
            // Если клик был вне сайдбара и вне кнопки — закрываем
            if (
                sidebarRef.current &&
                !sidebarRef.current.contains(event.target) &&
                buttonRef.current &&
                !buttonRef.current.contains(event.target)
            ) {
                setIsOpen(false)
            }
        }

        if (isOpen) {
            document.addEventListener("mousedown", handleClickOutside)
        }

        return () => {
            document.removeEventListener("mousedown", handleClickOutside)
        }
    }, [isOpen])
    

    const toggleSidebar = () => setIsOpen(!isOpen)

    return (
        <div className="relative p-2">
            <button
                ref={buttonRef}
                onClick={toggleSidebar}
                className="absolute top-0 left-0 z-50 px-2 bg-blue-600 text-white rounded hover:bg-blue-700 h-[30px]"
            >
                {isOpen ? "✖" : "☰"}
            </button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        ref={sidebarRef}
                        initial={{ x: -250 }}
                        animate={{ x: 0 }}
                        exit={{ x: -250 }}
                        transition={{ duration: 0.3 }}
                        className="fixed top-0 left-0 h-full w-64 bg-white shadow-lg z-40 p-6 "
                    >
                        <h2 className="text-xl font-bold mb-6 text-blue-600">Admin Panel</h2>
                        <ul className="flex flex-col gap-2 ">
                            
                            <li className="hover:bg-gray-200 cursor-pointer p-3 text-left text-xl font-semibold rounded-xl">
                                <Link to="/admin/dashboard" className="text-gray-700 hover:text-blue-600 ">📊 Boshqaruv</Link>
                            </li>
                            <li className="hover:bg-gray-200 cursor-pointer p-2 text-left text-xl font-semibold rounded-xl ">
                                <Link to="/admin/profile" className="text-gray-700 hover:text-blue-600 ">👥 Profil</Link>
                            </li>
                            <li className="hover:bg-gray-200 cursor-pointer p-2 text-left text-xl font-semibold rounded-xl absolute bottom-3 left-0 w-full text-center">
                                <Link to={'/admin/login '} onClick={()=>localStorage.removeItem('token')} className="text-red-500 hover:text-red-700 ">🚪Chiqish</Link>
                            </li>
                        </ul>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}
