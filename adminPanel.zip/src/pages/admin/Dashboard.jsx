import { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { store } from "../../store/store";
import {
    ApplicationList,
    ApplicationDetail,
    sendScoreWithAuth
} from "../../store/applications/applicationActions";
import AdminSidebar from "./AdminSideBar";

export default function Dashboard() {
    const applications = useSelector((a) => a.applicationsInfo.applications.results);
    const applicationDetail = useSelector((a) => a.applicationsInfo.applicationDetail);
    const [filter, setFilter] = useState("pending");
    const [selectedAppId, setSelectedAppId] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [applicationScore, setApplicationScore] = useState({});
    const [scoreError, setScoreError] = useState(null);
    const [scoredItems, setScoredItems] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [paginationInfo, setPaginationInfo] = useState({});

    const modalRef = useRef();

    useEffect(() => {
        const fetchPage = async () => {
            const response = await store.dispatch(ApplicationList(currentPage));
            if (response?.payload) {
                setPaginationInfo({
                    next: response.payload.next,
                    previous: response.payload.previous,
                    count: response.payload.count
                });
            }
        };
        fetchPage();
    }, [currentPage]);

    useEffect(() => {
        if (selectedAppId) {
            store.dispatch(ApplicationDetail(selectedAppId));
            setApplicationScore({});
            setScoredItems([]);
        }
    }, [selectedAppId]);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (modalRef.current && !modalRef.current.contains(event.target)) {
                setIsModalOpen(false);
            }
        };

        if (isModalOpen) {
            document.addEventListener("mousedown", handleClickOutside);
        }

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [isModalOpen]);

    const handleApplicationScoreSubmit = async (itemId) => {
        setScoreError(null);
        const value = applicationScore[itemId];
        if (value === undefined || value === "") {
            setScoreError("Iltimos, bahoni tanlang.");
            return;
        }

        try {
            const data = {
                item: itemId,
                value: Number(value)
            };
            await store.dispatch(sendScoreWithAuth(data));
            setScoredItems((prev) => [...prev, itemId]);
        } catch (err) {
            setScoreError(err.message);
        }
    };

    const filteredApps = applications?.filter(app => app.status === filter);

    const getStatusBadge = (status) => {
        switch (status) {
            case "pending":
                return <span className="text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-700 font-medium">Ko‘rib chiqilmoqda</span>;
            case "accepted":
                return <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700 font-medium">Tasdiqlandi</span>;
            default:
                return <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-700 font-medium">Noma'lum</span>;
        }
    };

    return (
        <div className="p-5 bg-gray-100 min-h-screen">
            <AdminSidebar />
            <h1 className="text-2xl font-bold mb-5">Boshqaruv paneli</h1>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="bg-white shadow rounded-lg p-4">
                    <p className="text-sm text-gray-500">Foydalanuvchilar soni</p>
                    <p className="text-2xl font-bold">143</p>
                </div>
                <div className="bg-white shadow rounded-lg p-4">
                    <p className="text-sm text-gray-500">Arizalar soni</p>
                    <p className="text-2xl font-bold">87</p>
                </div>
                <div className="bg-white shadow rounded-lg p-4">
                    <p className="text-sm text-gray-500">Faol arizalar</p>
                    <p className="text-2xl font-bold">{paginationInfo.count}</p>
                </div>
            </div>

            <div className="bg-white shadow rounded-lg p-5">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-semibold">Arizalar ro‘yxati</h2>
                    <select
                        value={filter}
                        onChange={e => setFilter(e.target.value)}
                        className="border px-3 py-2 rounded shadow-sm focus:outline-none"
                    >
                        <option value="pending">Ko‘rib chiqilmoqda</option>
                        <option value="accepted">Tasdiqlandi</option>
                    </select>
                </div>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-blue-50">
                            <tr>
                                <th className="px-4 py-2 text-center text-xs font-semibold text-gray-700 uppercase">#</th>
                                <th className="px-4 py-2 text-center text-xs font-semibold text-gray-700 uppercase">F.I.Sh</th>
                                <th className="px-4 py-2 text-center text-xs font-semibold text-gray-700 uppercase">ID</th>
                                <th className="px-4 py-2 text-center text-xs font-semibold text-gray-700 uppercase">Holati</th>
                                <th className="px-4 py-2 text-center text-xs font-semibold text-gray-700 uppercase">Yuborilgan</th>
                                <th className="px-4 py-2 text-center text-xs font-semibold text-gray-700 uppercase">Imkoniyatlar</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {filteredApps?.map((item, i) => (
                                <tr key={i} className="hover:bg-gray-50">
                                    <td className="px-4 py-2 text-sm text-center">{i + 1}</td>
                                    <td className="px-4 py-2 text-sm  font-medium text-center">{item.student.full_name}</td>
                                    <td className="px-4 py-2 text-sm text-center">{item.student.student_id_number}</td>
                                    <td className="px-4 py-2 text-sm text-center">{getStatusBadge(item.status)}</td>
                                    <td className="px-4 py-2 text-sm text-center">{new Date(item.submitted_at).toLocaleDateString("uz-UZ")}</td>
                                    <td className="px-4 py-2 text-sm text-center">
                                        <button
                                            className="px-2 py-1 text-white bg-blue-600 hover:bg-white hover:text-black hover:shadow transition"
                                            onClick={() => {
                                                setSelectedAppId(item.id);
                                                setIsModalOpen(true);
                                            }}
                                        >
                                            Ko‘rish
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {filteredApps?.length === 0 && (
                                <tr>
                                    <td colSpan="6" className="text-center py-4 text-gray-500">Mos keluvchi arizalar topilmadi</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Pagination controls */}
                {filteredApps?.length > 0 && (
                    <div className="flex justify-between items-center mt-4">
                        <button
                            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                            disabled={!paginationInfo.previous}
                            className={`px-4 py-2 rounded ${paginationInfo.previous ? "bg-blue-600 text-white hover:bg-blue-700" : "bg-gray-300 text-gray-500 cursor-not-allowed"}`}
                        >
                            ← Orqaga
                        </button>
                        <div className="flex gap-2 flex-wrap mt-4 justify-center">
                            {paginationInfo.count && (
                                Array.from({ length: Math.ceil(paginationInfo.count / 10) }, (_, index) => {
                                    const pageNumber = index + 1;
                                    return (
                                        <button
                                            key={pageNumber}
                                            onClick={() => setCurrentPage(pageNumber)}
                                            className={`px-3 py-1 rounded border ${
                                                currentPage === pageNumber
                                                    ? "bg-blue-600 text-white border-blue-600"
                                                    : "bg-white text-gray-700 hover:bg-blue-50 border-gray-300"
                                            }`}
                                        >
                                            {pageNumber}
                                        </button>
                                    );
                                })
                            )}
                        </div>

                        <button
                            onClick={() => setCurrentPage(prev => prev + 1)}
                            disabled={!paginationInfo.next}
                            className={`px-4 py-2 rounded ${paginationInfo.next ? "bg-blue-600 text-white hover:bg-blue-700" : "bg-gray-300 text-gray-500 cursor-not-allowed"}`}
                        >
                            Oldinga →
                        </button>
                    </div>
                )}
            </div>

            {isModalOpen && applicationDetail && applicationDetail.student && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div
                        ref={modalRef}
                        className="bg-white p-6 rounded-lg shadow-lg max-w-lg w-full relative max-h-[90vh] overflow-y-auto"
                    >
                        <button onClick={() => setIsModalOpen(false)} className="absolute top-2 right-2 text-gray-500">✖</button>
                        <h3 className="text-2xl font-semibold mb-4 ">Ariza tafsilotlari</h3>

                        <p><strong>F.I.Sh:</strong> {applicationDetail.student.full_name}</p>
                        <p><strong>ID:</strong> {applicationDetail.student.student_id_number}</p>
                        <p><strong>Holati:</strong> {getStatusBadge(applicationDetail.status)}</p>
                        <p><strong>Yuborilgan sana:</strong> {new Date(applicationDetail.submitted_at).toLocaleDateString("uz-UZ")}</p>

                        <div className="mt-4 space-y-6">
                            {applicationDetail.items?.map((item) => (
                                <div key={item.id} className="border-t pt-4">
                                    <p className="font-semibold text-gray-700">📘 Yo‘nalish: {item.direction_name}</p>

                                    {item.files?.length > 0 ? (
                                        <div className="mt-2">
                                            <a
                                                href={item.files[0].file}
                                                download
                                                className="text-blue-600 hover:underline"
                                            >
                                                🧾 Faylni yuklab olish
                                            </a>
                                        </div>
                                    ) : (
                                        <p className="text-[red]">Fayl yuklanmagan!</p>
                                    )}

                                    <div className="mt-3">
                                        <label className="block text-sm text-gray-600 mb-1">Baho:</label>
                                        <select
                                            value={applicationScore[item.id] || ""}
                                            onChange={(e) =>
                                                setApplicationScore((prev) => ({
                                                    ...prev,
                                                    [item.id]: e.target.value
                                                }))
                                            }
                                            className="w-full border px-3 py-2 rounded shadow-sm"
                                            disabled={scoredItems.includes(item.id)}
                                        >
                                            <option value="">Bahoni tanlang</option>
                                            {[...Array(11).keys()].map(num => (
                                                <option key={num} value={num}>{num}</option>
                                            ))}
                                        </select>

                                        <button
                                            disabled={scoredItems.includes(item.id) || !applicationScore[item.id]}
                                            onClick={() => handleApplicationScoreSubmit(item.id)}
                                            className={`mt-2 px-4 py-2 rounded transition ${
                                                scoredItems.includes(item.id)
                                                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                                                    : 'bg-blue-600 text-white hover:bg-blue-700'
                                            }`}
                                        >
                                            Saqlash
                                        </button>

                                        {scoredItems.includes(item.id) && (
                                            <p className="text-green-600 mt-2 font-medium">✅ Baholandi</p>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>

                        {scoreError && (
                            <p className="text-red-600 font-medium text-sm mt-4">❌ {scoreError}</p>
                        )}
                    </div>
                </div>
            )}

        </div>
    );
}
