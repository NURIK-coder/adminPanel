import { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { store } from "../../store/store"
import { ApplicationList } from "../../store/applications/applicationActions"
import { useNavigate } from "react-router-dom"

export default function Applications() {
    const applications = useSelector(a => a.applicationsInfo.applications)
    console.log(applications);

    const navigate = useNavigate()
    const [selectedApp, setSelectedApp] = useState(null)
    const [score, setScore] = useState("")

    useEffect(() => {
        store.dispatch(ApplicationList())
        const token = localStorage.getItem('token')
        if (!token) {
            navigate('/admin/login')
        }
    }, [])

    const getStatusBadge = (status) => {
        switch (status) {
            case "pending":
                return <span className="text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-700 font-medium">Ko‘rib chiqilmoqda</span>;
            case "authorized":
                return <span className="text-xs px-2 py-1 rounded-full bg-orange-100 text-orange-700 font-medium">Tasdiqlangan</span>;
            case "paid":
                return <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700 font-medium">To‘langan</span>;
            default:
                return <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-700 font-medium">Noma'lum</span>;
        }
    };

    const handleSave = () => {
        console.log("Ball saqlandi:", score, " | Ariza ID:", selectedApp.id)
        // TODO: jo‘natish uchun API chaqiruvi (sendScore(selectedApp.id, score))
        setSelectedApp(null)
        setScore("")
    }

    return (
        <div className="p-5">
            <div className="mb-5">
                <h1 className="text-2xl font-bold text-gray-800">Arizalar ro‘yxati</h1>
            </div>

            <div className="overflow-x-auto bg-white shadow-xl rounded-xl">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-blue-100">
                        <tr>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">#</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">F.I.Sh</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Talaba ID</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Holati</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Yuborilgan sana</th>
                            <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 uppercase">Harakat</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {applications?.map((item, index) => (
                            <tr key={index} className="hover:bg-gray-50 transition-all">
                                <td className="px-4 py-2 text-sm text-gray-700">{index + 1}</td>
                                <td className="px-4 py-2 text-sm font-medium text-gray-900">{item.student.full_name}</td>
                                <td className="px-4 py-2 text-sm text-gray-700">{item.student.student_id_number}</td>
                                <td className="px-4 py-2 text-sm">
                                    {getStatusBadge(item.status)}
                                </td>
                                <td className="px-4 py-2 text-sm text-gray-600">
                                    {new Date(item.submitted_at).toLocaleDateString("uz-UZ")}
                                </td>
                                <td className="px-4 py-2 text-center">
                                    <button
                                        className="text-sm text-blue-600 hover:underline"
                                        onClick={() => navigate(`/admin/applications/${item.id}`)}
                                    >
                                        Ko‘rish
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {applications?.length === 0 && (
                            <tr>
                                <td colSpan="6" className="text-center py-5 text-gray-500">Hech qanday ariza topilmadi</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
            {/* Modal */}
            {selectedApp && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white p-6 rounded-lg w-full max-w-md shadow-lg relative">
                        <button
                            onClick={() => setSelectedApp(null)}
                            className="absolute top-2 right-3 text-gray-500 hover:text-gray-700 text-xl"
                        >
                            ×
                        </button>
                        <h2 className="text-lg font-bold text-gray-800 mb-4">Talaba haqida</h2>
                        <p><span className="font-semibold">F.I.Sh:</span> {selectedApp.student.full_name}</p>
                        <p><span className="font-semibold">Talaba ID:</span> {selectedApp.student.student_id_number}</p>
                        <p><span className="font-semibold">Yuborilgan:</span> {new Date(selectedApp.submitted_at).toLocaleString("uz-UZ")}</p>

                        <div className="mt-4">
                            <label className="block mb-1 font-semibold text-sm text-gray-700">Bahoni kiriting (0–100):</label>
                            <input
                                type="number"
                                min={0}
                                max={100}
                                value={score}
                                onChange={(e) => setScore(e.target.value)}
                                className="w-full border px-3 py-2 rounded focus:outline-blue-400"
                            />
                        </div>

                        <div className="mt-5 flex justify-end gap-3">
                            <button
                                onClick={() => setSelectedApp(null)}
                                className="px-4 py-2 border rounded text-gray-600 hover:bg-gray-100"
                            >
                                Bekor qilish
                            </button>
                            <button
                                onClick={handleSave}
                                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                            >
                                Saqlash
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}
