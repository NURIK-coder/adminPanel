import logo from './logo.svg';
import './App.css';
import Main from './components/Main';
import TestPage from './pages/Test';

function App() {
  return (
    <div className="App">
      <Main />
    </div>
  );
}

export default App;
